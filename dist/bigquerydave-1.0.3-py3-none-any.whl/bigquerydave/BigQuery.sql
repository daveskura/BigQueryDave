/*
  -- Dave Skura, 2023
*/

SELECT CURRENT_TIMESTAMP