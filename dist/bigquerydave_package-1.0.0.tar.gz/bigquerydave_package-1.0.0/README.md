# BigQueryDave

A wrapper on the bigquery libraries for simple access
