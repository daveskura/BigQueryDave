"""
  Dave Skura

"""
from bigquerydave_package.bigquerydave import gcp

gcp().list_gcp_projects()


