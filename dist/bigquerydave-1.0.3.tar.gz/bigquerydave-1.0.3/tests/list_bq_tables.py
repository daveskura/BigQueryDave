"""
  Dave Skura

"""
from bigquerydave_package.bigquerydave import bq

bq().list_bq_tables('watchful-lotus-364517.dave')
