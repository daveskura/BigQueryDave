"""
  Dave Skura
  
  File Description:
"""
from bigquerydave_package.bigquerydave import bq

bq().list_bq_datasets()
